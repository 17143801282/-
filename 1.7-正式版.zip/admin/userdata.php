<?php
/*
* File：管理账号密码数据文件
* Author：易如意
* QQ：51154393
* Url：www.eruyi.cn
*/

$user = 'admin';//后台账号

$pass = 'admin';//后台密码

$cookie = '91e34bc92dd9475c96136be83b8d7124';

/* 请手动修改以上账号密码信息 */
?>