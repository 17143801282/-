<?php
define('DB_HOST','localhost');//数据库连接地址，默认：localhost或127.0.0.1
define('DB_USER','root');//数据库账号
define('DB_PASSWD','root');//数据库密码
define('DB_NAME','user');//数据库名称
define('DB_PRE','eruyi_');//数据库前缀
?>