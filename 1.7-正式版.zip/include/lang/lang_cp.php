<?php
$lang_adm = [//管理日志
	
];


$lang_user = [//用户操作日志
	'user_logon' => '登录',
	'inv' => '邀请注册',
	'upic' => '上传头像',
	'set_up' => '设置账号密码',
	'alter_name' => '修改名称',
	'afcrc' => '获取验证码',
	'alter_pass' => '修改密码',
	'pay' => '请求支付',
	'get_fen' => '积分验证',
	'clock' => '打卡签到',
	'card' => '卡密充值',
	'wx_login' => '微信登录',
	'wx_bind' => '绑定微信',
	'qq_login' => 'QQ登录',
	'qq_bind' => '绑定QQ',
	'seek_pass'=>'找回密码',
	'email_bind' => '绑定邮箱',
	'email_untie' => '解绑邮箱',
	'pay_success' => '在线充值',
];
?>